<?php
// توقيع المطوّر: يوسف الحمزي — Y- Dimensions — yswefalhmzy@gmail.com (بداية الملف)
return ['server_root' => dirname(__DIR__, 2)];
// توقيع المطوّر: يوسف الحمزي — Y- Dimensions — yswefalhmzy@gmail.com (نهاية الملف)
