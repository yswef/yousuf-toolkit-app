<!-- توقيع المطوّر: يوسف الحمزي — Y- Dimensions — yswefalhmzy@gmail.com (بداية الملف) -->
# تثبيت لوحة Y- Dimensions التنفيذية داخل لوحة أم موجودة

هذه الحزمة **لا تُفرَّغ في جذر `public_html/`**. جذر الدومين فيه مسبقاً `config.php`،
`config-sample.php`، `index.php`، `admin/`، `app/`، `assets/`، `core/`، `data/`،
`docs/`، `lang/`، `cron_*.php`، `status.php`، `update_start.php`، `update_step.php`،
و`manifest.webmanifest`. كلها تبقى كما هي ولا تُستبدل.

هذه الحزمة منشورة داخل المستودع في `docs/mother-panel/y-dimensions-mother-panel.zip`
وتُرفق تلقائياً كأصل في كل إصدار `v*` يبنيه `.github/workflows/release.yml`؛
رابط المستودع: https://github.com/yswef/yousuf-toolkit-app/blob/dev/docs/mother-panel/y-dimensions-mother-panel.zip
لا تُؤخذ من مجلد `build/` المستثنى من Git، ولا تُنسَب إلى إصدار قديم لم يحتوِ هذا الأصل.

## 1. أين تُستخرج؟

اسأل لوحة الأم عن `{mother_panel.apps_dir}` وعن المجلد الذي خصصته للتطبيق،
وليكن مثلاً `<allocated-folder>` (مثال فقط: `public_html/apps/y-dimensions/`).
استخرج **محتويات هذا الملف المضغوط مباشرة داخل `<allocated-folder>`**، بلا مجلد إضافي فوقها:

```
<allocated-folder>/
├── .htaccess
├── INSTALL.md
├── mother-panel.json
├── config/          ← config.example.php + .htaccess، وأنشئ config.php هنا فقط
├── src/             ← محمي بـ .htaccess
├── migrations/      ← محمي بـ .htaccess
└── public/
    ├── .htaccess
    ├── index.php     ← فحص صحة JSON
    ├── api/          ← نقاط API الحقيقية
    ├── content/VERSION
    ├── learn/
    └── panel/        ← لوحة التحكم التنفيذية (18 تبويباً)
```

إن كان في لوحة الأم زر «رفع حزمة تطبيق / Install from ZIP»، ارفع هذا الملف هناك واتركها
تُنشئ المجلد وتُرجع لك الرابط. إن لم يوجد، أنشئ المجلد من File Manager وارفع الحزمة
ثم `Extract` داخله. **لا تختر `public_html/` كوجهة الاستخراج.**

## 2. الإعداد

1. انسخ `config/config.example.php` إلى `config/config.php` **داخل المجلد المخصص**.
2. املأ `db`, `base_url`, `license_secret`, `admin_token`, `allowed_origins` من مالك
   لوحة الأم/الاستضافة فقط. لا تخمّنها، ولا تلمس `public_html/config.php` ولا
   `public_html/config-sample.php`، ولا ترفع `config.php` إلى Git.
3. `base_url` هو رابط المجلد العام الذي تعطيه لوحة الأم، مثالاً:
   `https://<domain>/<allocated-path>/public` (بدون `/panel` في النهاية).

## 3. قاعدة البيانات — مهم

القاعدة واحدة و`users` موحّد كما في `docs/dev/RULES.md` و`MOTHER_PANEL_HANDOFF.md`.
ملف `migrations/001_init.sql` في هذه الحزمة **ينشئ جدول `users`**؛ لذلك لا تستورده كما هو
على قاعدة لوحة الأم الموحّدة. المطلوب من موديل لوحة الأم تنفيذ عقد التسليم: ربط الجداول
الموحّدة، واستيراد الترحيلات غير المكررة فقط (`002_admin.sql`…`006_learning.sql` بعد
التأكد)، أو تعديل `001_init.sql` إلى `CREATE TABLE IF NOT EXISTS` مع بقاء `users` الأصلي.
إلى أن يتم ذلك تعمل اللوحة في **وضع القراءة فقط** بالبيانات المحلية؛ لا تُعلن اكتمال التشغيل.

## 4. الروابط التي تُرجعها لوحة الأم

بعد الاستخراج تكتب لوحة الأم في بطاقة `y-dimensions`:

- `app_public_url = https://<domain>/<allocated-path>/public`
- `panel_url      = https://<domain>/<allocated-path>/public/panel/`
- `api_base       = app_public_url` (أو `.../public/panel` لأن `panel/api/*.php` تحوّل الطلبات)
- `mother_panel.apps.open_panel` → `panel_url` في **تبويب/صفحة جديدة**.

اللوحة ترسل `X-Frame-Options: DENY` افتراضياً؛ إن أردت عرضها داخل إطار في لوحة الأم،
فضبط `YD_PANEL_PREVIEW=1` يكون من إعداد لوحة الأم/الخادم فقط، لا من هذه الحزمة العامة،
لأن تفعيله يسمح بتضمين اللوحة في أي موقع.

## 5. جعل التطبيق يتواصل مع المجلد

في التطبيق: شاشة الحساب ← «عنوان API للخادم» ← ضع `api_base` أعلاه. هذا يكفي للأجهزة
المثبتة بلا إصدار جديد. إن أردت أن يكون الرابط الافتراضي في كل بناء، غيّر
`config/environments.json` → `apiBaseUrl` إلى `api_base`، ثم شغّل من جذر المستودع:

```bash
python3 server/tools/build_panel_data.py
python3 server/tools/build_mother_panel_zip.py
```

ثم أعد بناء APK إن أردت تغيير الافتراضي داخل التطبيق. لا يُنشأ وسم/إصدار جديد في هذه الخطوة.

## 6. اللوحة التابعة لا تدخل هذه الحزمة

`server/public/boards/y-dimensions/` بـ`MAP.json` و25 ملفاً تُثبّت وحدها داخل
`{mother_panel.boards_dir}/y-dimensions/` عبر `mother_panel.install.map` ثم
`mother_panel.verify.run`. لا تُنسخ داخل هذه الحزمة ولا داخل `public/`.

## 7. التحقق

- `GET app_public_url/` → JSON فيه `ok=true`.
- `GET app_public_url/api/content.php?action=manifest` → JSON لا HTML.
- `GET panel_url?p=learning` → تبويبات اللوحة ومنها مراجعة الخطط.
- بطاقة `y-dimensions` في لوحة الأم تفتح `panel_url`.
- من التطبيق: إنشاء حساب/تسجيل دخول على `api_base` يرجع JSON.

إن استُخرجت الحزمة في `public_html/` بالغلط، احذف الملفات التي أنشأتها داخل الجذر فقط،
ولا تحذف `config.php` أو `index.php` أو مجلدات الموقع/لوحة الأم الأصلية.

الشرح الكامل: `docs/mother-panel/UPLOAD_TO_MOTHER_PANEL.md`.
<!-- توقيع المطوّر: يوسف الحمزي — Y- Dimensions — yswefalhmzy@gmail.com (نهاية الملف) -->
